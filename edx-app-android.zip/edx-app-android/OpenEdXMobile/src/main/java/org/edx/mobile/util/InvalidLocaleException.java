package org.edx.mobile.util;

public class InvalidLocaleException extends Exception {
    public InvalidLocaleException(String msg) {
        super(msg);
    }
}
