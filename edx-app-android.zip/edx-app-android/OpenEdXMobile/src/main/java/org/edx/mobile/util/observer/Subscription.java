package org.edx.mobile.util.observer;

public interface Subscription {
    void unsubscribe();
}
