package org.edx.mobile.util.observer;

public interface Func1<T, U> {
    U call(T arg);
}
